import React from "react";
import style from "./rating.module.css";
import { Container, Image } from "react-bootstrap";
import { useSelector } from "react-redux";

const RatingCaption = () => {
  const { isLoading, screenData } = useSelector((state) => state.home);
  const { brandSection, companySection } = screenData;

  return (
    <div className={style.rating}>
      <Container className="">
        {/* ukryte: oceny i loga */}

        <div className={style.ratingMainImg}>
          <Image
            src={brandSection?.banner_image}
            alt="rating image"
            width={500}
            height={300}
          />
          <p><span>{brandSection?.banner_text}</span></p>
        </div>
        {/* ukryte: oceny i loga */}
        <div className={style.ratingCOntent}>
          <h2>{companySection?.main_title}</h2>
          <p>{companySection?.subtitle1}</p>
          <p>{companySection?.subtitle2}</p>
        </div>
      </Container>
    </div>
  );
};

export default RatingCaption;
