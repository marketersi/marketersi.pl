// "use client";
// import Hero from "@/components/organisms/main/Hero/Hero";
// import Entrepreneur from "@/components/organisms/main/entrepreneur/Entrepreneur";
// import MarkSide from "@/components/organisms/main/mark-side-card/MarkSide";
// import RatingCaption from "@/components/organisms/main/rating-captions/RatingCaption";
// import Numbers from "@/components/organisms/main/numbers/Numbers";
// import HardResult from "@/components/organisms/main/hard-results/HardResults";
// import React, { useEffect } from "react";
// import Order from "@/components/organisms/main/order/Order";
// import Video from "@/components/organisms/main/video/Video";
// import OurClients from "@/components/organisms/main/ourclients/OurClients";
// import { useDispatch, useSelector } from "react-redux";
// import { FETCH_HOME_SCREEN_DATA } from "@/redux/home/homeAction";
// import BounceLoader from "react-spinners/BounceLoader";
// import "./home.css";
// import { Provider } from 'react-redux';
// import store from "@/store/store";

// interface HomeState {
//   isLoading: boolean;
//   screenData: any;
// }

// export interface RootState {
//   home: HomeState;
// }
// const HomeScreen = () => {
//   const { isLoading, screenData } = useSelector(
//     (state: RootState) => state.home
//   );
//   const dispatch = useDispatch();

//   if (screenData) {
//     console.log("home screen data from UI => ", screenData);
//   }

//   useEffect(() => {
//     console.log("Home Page Test....");
//   }, []);

//   useEffect(() => {
//     dispatch({ type: FETCH_HOME_SCREEN_DATA });
//   }, [dispatch]);

//   return (
//     <>
//       {isLoading ? (
//         <div className="loader-container">
//           <BounceLoader color="#00bfff" size={50} />
//         </div>
//       ) : (
//         <div>
//           <Provider store={store}>
//             <div className="overflow-fulldiv">
//               <Hero />
//               <Video />
//               <RatingCaption />
//             </div>

//             <MarkSide />
//             <OurClients />
//             <Entrepreneur />
//             <Numbers />
//             <HardResult />
//             <Order />
//           </Provider>
//         </div>
//       )}
//     </>
//   );
// };

// export default HomeScreen;
// home/page.tsx
"use client";
import Hero from "@/components/organisms/main/Hero/Hero";
import Entrepreneur from "@/components/organisms/main/entrepreneur/Entrepreneur";
import MarkSide from "@/components/organisms/main/mark-side-card/MarkSide";
import RatingCaption from "@/components/organisms/main/rating-captions/RatingCaption";
import Numbers from "@/components/organisms/main/numbers/Numbers";
import HardResult from "@/components/organisms/main/hard-results/HardResults";
import React, { useEffect } from "react";
import Order from "@/components/organisms/main/order/Order";
import Video from "@/components/organisms/main/video/Video";
import OurClients from "@/components/organisms/main/ourclients/OurClients";
import { useDispatch, useSelector } from "react-redux";
import { FETCH_HOME_SCREEN_DATA } from "@/redux/home/homeAction";
import ScrollManager from "../ScrollManager";
import BounceLoader from "react-spinners/BounceLoader";
import "./home.css";
import { Provider } from 'react-redux';
import store from "@/store/store";

interface HomeState {
  isLoading: boolean;
  screenData: any;
}

export interface RootState {
  home: HomeState;
}

const HomeScreen = () => {
  const { isLoading, screenData } = useSelector(
    (state: RootState) => state.home
  );
  const dispatch = useDispatch();

  if (screenData) {
    console.log("home screen data from UI => ", screenData);
  }

  // useEffect(() => {
  //   console.log("Home Page Test....");
  //   if ('scrollRestoration' in history) {
  //     history.scrollRestoration = 'manual';
  //   }
  // }, []); // Empty dependency array means it runs once on mount

  useEffect(() => {
    if (!screenData || Object.keys(screenData).length === 0) {
     dispatch({ type: FETCH_HOME_SCREEN_DATA });
    }
  }, [screenData, dispatch]);
  // useEffect(() => {
  //   dispatch({ type: FETCH_HOME_SCREEN_DATA });
  // }, [dispatch]);

  return (
    <>
      {isLoading ? (
        <div className="loader-container">
          <BounceLoader color="#00bfff" size={50} />
        </div>
      ) : (
        <div>
          <Provider store={store}>
            <ScrollManager/>
            <div className="overflow-fulldiv">
              <Hero />
              <Video />
              <RatingCaption />
            </div>

            <MarkSide />
            {/* ukryte: cudze opinie/realizacje */}
            <Entrepreneur />
            <Numbers />
            <HardResult />
            <Order />
          </Provider>
        </div>
      )}
    </>
  );
};

export default HomeScreen;